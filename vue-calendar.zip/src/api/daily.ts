async function sleep(timeout: number) {
  return new Promise((resolve) => setTimeout(resolve, timeout))
}

// 获取服务器时间
export const getServerTime = async () => {
  await sleep(50)
  return Date.now()
}

// 获取一周日报
export const getWeekDaily = async (params: { user: string, time: number }) => {
  await sleep(100)
  return [
    [],
    [],
    [],
    [
      {
        id: 1,
        title: '设计：质量管理V2.0功能',
        detail: '1.xxxx\n2.xxx',
        type: '0',
        start: new Date('2023-03-13T08:00:00').getTime(),
        end: new Date('2023-03-13T10:00:00').getTime()
      },
      {
        id: 2,
        title: '客户支持：AMI（国泰君安xx团队）',
        detail: '1.xxxx\n2.xxx',
        type: '1',
        start: new Date('2023-03-13T08:00:00').getTime(),
        end: new Date('2023-03-13T11:00:00').getTime()
      },
      {
        id: 3,
        title: '设计：质量管理V2.0功能',
        detail: '1.xxxx\n2.xxx',
        type: '2',
        start: new Date('2023-03-13T09:30:00').getTime(),
        end: new Date('2023-03-13T12:00:00').getTime()
      },
      {
        id: 4,
        title: '设计：质量管理V2.0功能',
        detail: '1.xxxx\n2.xxx',
        type: '3',
        start: new Date('2023-03-13T10:00:00').getTime(),
        end: new Date('2023-03-13T12:30:00').getTime()
      },
      {
        id: 5,
        title: '客户支持：AMI（国泰君安xx团队）',
        detail: '1.xxxx\n2.xxx',
        type: '1',
        start: new Date('2023-03-13T10:30:00').getTime(),
        end: new Date('2023-03-13T11:30:00').getTime()
      },
      {
        id: 6,
        title: '客户支持：AMI（国泰君安xx团队）',
        detail: '1.xxxx\n2.xxx',
        type: '4',
        start: new Date('2023-03-13T11:00:00').getTime(),
        end: new Date('2023-03-13T12:30:00').getTime()
      },
      {
        id: 7,
        title: '设计：质量管理V2.0功能',
        detail: '1.xxxx\n2.xxx',
        type: '2',
        start: new Date('2023-03-13T11:30:00').getTime(),
        end: new Date('2023-03-13T13:30:00').getTime()
      },
      {
        id: 8,
        title: '客户支持：AMI（国泰君安xx团队）',
        detail: '1.xxxx\n2.xxx',
        type: '4',
        start: new Date('2023-03-13T05:05:00').getTime(),
        end: new Date('2023-03-13T07:05:00').getTime()
      }
    ]
  ]
}

// 获取用户列表
export const getUserList = async () => {
  await sleep(200)
  return [
    {
      name: '周乘风',
      id: '0'
    },
    {
      name: '廖志勇',
      id: '1'
    }
  ]
}

// 获取工作类型
export const getWorkTypes = async () => {
  await sleep(1000)
  return [{
    name: '开发',
    id: '0',
  }, {
    name: '缺陷修复',
    id: '1'
  }, {
    name: '测试与定位',
    id: '2'
  }, {
    name: '客户支持与交流',
    id: '3'
  }, {
    name: '会议',
    id: '4'
  }]
}

// 获取缺陷列表
export const getDefects = async () => {
  await sleep(300)
  return []
}

// 获取测试用例
export const getTestCases = async () => {
  await sleep(300)
  return []
}

// 获取流水线列表
export const getPipelines = async () => {
  await sleep(300)
  return []
}

// 获取项目
export const getProjects = async () => {
  await sleep(300)
  return []
}

// 获取客户
export const getCustomers = async (params: { project: string, type: string }) => {
  await sleep(300)
  return []
}