export interface SegSpan {
  start: number
  end: number
}

export interface SegEntry {
  index: number
  thickness: number // should be an integer
  span: SegSpan
}

// used internally. exposed for subclasses of SegHierarchy
export interface SegInsertion {
  level: number // will have an equal coord, or slightly before, entries in existing level
  levelCoord: number
  lateral: number // where to insert in the existing level. -1 if creating a new level
  touchingLevel: number // -1 if no touching
  touchingLateral: number // -1 if no touching
  touchingEntry: SegEntry // the last touching entry in the level
  stackCnt: number
}

export interface SegRect extends SegEntry {
  levelCoord: number
}

export class SegHierarchy {
  // settings
  // strictOrder: boolean = false
  allowReslicing: boolean = false
  // maxCoord: number = -1 // -1 means no max
  // maxStackCnt: number = -1 // -1 means no max

  levelCoords: number[] = [] // ordered顺序
  entriesByLevel: SegEntry[][] = [] // parallel with levelCoords 二维数组，与levelCoords平行
  stackCnts: { [entryId: string]: number } = {} // entry出现的次数

  addSegs(inputs: SegEntry[]): void {
    for (let i = 0, l = inputs.length; i < l; i++) {
      const entry = inputs[i]
      const insertion = this.findInsertion(entry)
      this.insertEntryAt(entry, insertion)
    }
  }

  insertEntryAt(entry: SegEntry, insertion: SegInsertion): void {
    const { entriesByLevel, levelCoords } = this
    const { lateral, level, levelCoord, stackCnt } = insertion

    if (lateral === -1) {
      // create a new level
      insertAt(levelCoords, level, levelCoord)
      insertAt(entriesByLevel, level, [entry])
    } else {
      // insert into existing level
      insertAt(entriesByLevel[level], lateral, entry)
    }

    this.stackCnts[buildEntryKey(entry)] = stackCnt
  }

  findInsertion(newEntry: SegEntry): SegInsertion {
    // debugger
    // let { levelCoords, entriesByLevel, strictOrder, stackCnts } = this
    const { levelCoords, entriesByLevel, stackCnts } = this
    const levelCnt = levelCoords.length
    let candidateCoord = 0 // 候选项坐标
    let touchingLevel: number = -1
    let touchingLateral: number = -1
    let touchingEntry: SegEntry | null = null
    let stackCnt = 0

    for (let trackingLevel = 0; trackingLevel < levelCnt; trackingLevel += 1) {
      const trackingCoord = levelCoords[trackingLevel]

      // 如果 当前到达的坐标已经超过 候选项坐标 + 1，那么可以终止循环
      // if the current level is past the placed entry, we have found a good empty space and can stop.
      if (trackingCoord >= candidateCoord + newEntry.thickness) {
        break
      }

      let trackingEntries = entriesByLevel[trackingLevel]
      let trackingEntry: SegEntry
      // 查找新条目结束后的第一个条目
      let searchRes = binarySearch(trackingEntries, newEntry.span.start, getEntrySpanEnd) // find first entry after newEntry's end
      // 如果完全匹配（不冲突），请转到下一个
      let lateralIndex = searchRes[0] + searchRes[1] // if exact match (which doesn't collide), go to next one

      while ( // 当前列的位置有冲突
        (trackingEntry = trackingEntries[lateralIndex]) && // but not past the whole entry list
        trackingEntry.span.start < newEntry.span.end // and not entirely past newEntry
      ) {
        // 跳到下一列：当前坐标+1
        let nextCoord = trackingCoord + trackingEntry.thickness
        // 与候选项的顶部相交?
        if (nextCoord > candidateCoord) {
          candidateCoord = nextCoord
          touchingEntry = trackingEntry
          touchingLevel = trackingLevel
          touchingLateral = lateralIndex
        }
        // butts up against top of candidate? (will happen if just intersected as well)
        // 与候选人对接？（如果只是相交也会发生）
        if (nextCoord === candidateCoord) {
          // accumulate the highest possible stackCnt of the trackingEntries that butt up
          // 累积跟踪条目的最高可能堆栈Cnt对接的条目
          stackCnt = Math.max(stackCnt, stackCnts[buildEntryKey(trackingEntry)] + 1)
        }
        lateralIndex += 1
      }
    }

    // the destination level will be after touchingEntry's level. find it
    let destLevel = 0
    if (touchingEntry) {
      destLevel = touchingLevel + 1
      while (destLevel < levelCnt && levelCoords[destLevel] < candidateCoord) {
        destLevel += 1
      }
    }

    // if adding to an existing level, find where to insert
    let destLateral = -1
    if (destLevel < levelCnt && levelCoords[destLevel] === candidateCoord) {
      destLateral = binarySearch(entriesByLevel[destLevel], newEntry.span.end, getEntrySpanEnd)[0]
    }

    return {
      touchingLevel,
      touchingLateral,
      touchingEntry: touchingEntry as SegEntry,
      stackCnt,
      levelCoord: candidateCoord,
      level: destLevel,
      lateral: destLateral,
    }
  }
}

export function getEntrySpanEnd(entry: SegEntry) {
  return entry.span.end
}

export function buildEntryKey(entry: SegEntry) { // TODO: use Map instead?
  return entry.index + ':' + entry.span.start
}

function insertAt<Item>(arr: Item[], index: number, item: Item) {
  arr.splice(index, 0, item)
}

export function binarySearch<Item>(
  a: Item[], // 旧条目数组
  searchVal: number, // 新条目起始值
  getItemVal: (item: Item) => number,
): [number, number] { // returns [level, isExactMatch ? 1 : 0]
  // debugger
  let startIndex = 0
  let endIndex = a.length // exclusive

  // 如果条目数为0 或者 如果新条目的起始值小于旧条目的终止值，那么相交
  if (!endIndex || searchVal < getItemVal(a[startIndex])) { // no items OR before first item
    return [0, 0]
  }

  // 坐标值为 endIndex
  if (searchVal > getItemVal(a[endIndex - 1])) { // after last item
    return [endIndex, 0]
  }

  // 完全匹配， 起始值与终止值相等
  while (startIndex < endIndex) {
    let middleIndex = Math.floor(startIndex + (endIndex - startIndex) / 2)
    let middleVal = getItemVal(a[middleIndex])

    if (searchVal < middleVal) {
      endIndex = middleIndex
    } else if (searchVal > middleVal) {
      startIndex = middleIndex + 1
    } else { // equal!
      return [middleIndex, 1]
    }
  }

  return [startIndex, 0]
}
