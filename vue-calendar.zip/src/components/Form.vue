<template>
  <el-form :model="model" size="small" label-width="60px">
    <el-form-item label="工作类型">
      <el-select v-model="model.workType" @change="changeWorkType" placeholder="请选择工作类型">
        <el-option v-for="workTypeItem in workTypes" :label="workTypeItem.name" :value="workTypeItem.id"></el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="耗时">
      <el-time-select v-model="model.start" :max-time="model.end === '00:00' ? '' : model.end" placeholder="开始时间"
        start="00:00" step="00:15" end="23:45" :clearable="false" @change="(val: string) => emit('onStartChange', val)" />
      <el-time-select v-model="model.end" :min-time="model.start" placeholder="结束时间"
        :start="model.start ? model.start : '00:15'" step="00:15" end="24:00"
        @change="(val: string) => emit('onEndChange', val)" />
    </el-form-item>

    <!-- 开发 -->
    <template v-if="model.workType === '0'">
      <el-form-item label="任务">
        <el-select v-model="model.task" placeholder="请选择任务">
          <el-option v-for="task in tasks" :label="task.name" :value="task.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="总进度">
        <el-progress style="flex: 1" :percentage="totalProgress" :indeterminate="indeterminate" />
      </el-form-item>
    </template>

    <template v-if="model.workType === '1'">
      <el-form-item label="缺陷">
        <el-select v-model="model.task" placeholder="请选择缺陷">
          <el-option v-for="defect in defects" :label="defect.name" :value="defect.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="总进度">
        <el-progress style="flex: 1" :percentage="totalProgress" :indeterminate="indeterminate" />
      </el-form-item>
    </template>

    <!-- 定位 -->
    <template v-if="model.workType === '2'">
      <el-form-item label="类型">
        <el-radio-group v-model="model.type" @change="changeTestType">
          <el-radio label="1">缺陷</el-radio>
          <el-radio label="2">测试用例</el-radio>
          <el-radio label="3">流水线</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-if="model.type === 1" label="缺陷">
        <el-select v-model="model.defects">
          <el-option v-for="defect in defects" :label="defect.name" :value="defect.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-else-if="model.type === 2" label="测试用例">
        <el-select v-model="model.testCases">
          <el-option v-for="testCase in testCases" :label="testCase.name" :value="testCase.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-else-if="model.type === 3" label="流水线">
        <el-select v-model="model.pipelines">
          <el-option v-for="pipeline in pipelines" :label="pipeline.name" :value="pipeline.id"></el-option>
        </el-select>
      </el-form-item>
    </template>

    <!-- 客户支持与交流 -->
    <template v-if="model.workType === '3'">
      <el-form-item label="项目">
        <el-select v-model="model.project">
          <el-option v-for="project in projects" :label="project.name" :value="project.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="类型">
        <el-radio-group v-model="model.type">
          <el-radio label="poc">售前客户</el-radio>
          <el-radio label="jf">交付项目</el-radio>
          <el-radio label="cpx">产品线</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="客户">
        <el-select v-model="model.project">
          <el-option v-for="customer in customers" :label="customer.name" :value="customer.id"></el-option>
        </el-select>
      </el-form-item>
    </template>

    <el-form-item label="详情">
      <el-input v-model="model.detail" :rows="5" type="textarea" placeholder="请输入" />
    </el-form-item>
  </el-form>
</template>

<script setup lang="ts">
import { shallowRef } from 'vue'
import { debounce, omit } from 'radash'
import { getWorkTypes, getDefects } from '../api/daily'

interface Option {
  name: string,
  id: string
}

const props = defineProps<{
  model: Record<string, any>,
  workTypes: any[]
}>()

const emit = defineEmits<{
  (e: 'onStartChange', value: string): void
  (e: 'onEndChange', value: string): void
}>()

const indeterminate = shallowRef(false)
const totalProgress = shallowRef(50)

// 任务列表
const tasks = shallowRef<Option[]>([])
// 缺陷列表
const defects = shallowRef<Option[]>([])
// 测试用例
const testCases = shallowRef<Option[]>([])
// 流水线
const pipelines = shallowRef<Option[]>([])
// 项目
const projects = shallowRef<Option[]>([])
// 客户
const customers = shallowRef<Option[]>([])

const changeWorkType = (type: string) => {
  const model = props.model
  switch (type) {
    // 开发
    case '2': {
      // 如果切换到测试与定位，默认切换到缺陷
      model.type = '1'
      break
    }
    case '3': {
      // 默认切换到售前客户类型
      model.type = 'poc'
      break
    }
    default: {
      model.type = ''
    }
  }
  console.log(model)
}

const changeTestType = debounce({ delay: 100 }, () => {
  // 请求不同类型的数据 缺陷 | 测试用例 | 流水线
  // 默认先请求缺陷列表
})

</script>

<style lang="scss" scoped></style>