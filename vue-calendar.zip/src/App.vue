<script setup lang="ts">
import { useDaily, ROLES } from './useDaily'
import {
  ArrowLeft,
  ArrowRight,
  Close,
  EditPen,
  Delete
} from '@element-plus/icons-vue'
import Form from './components/Form.vue'

const {
  params,
  workTypes,
  user,
  placeholderStyle,
  timeRange,
  shouldDragAndMove,
  placeholderVisible,
  popoverVStyle,
  popoverVisible,
  editDialogVisible,
  detailVisible,
  popoverStyle,
  currentCol,
  hours,
  daysInWeek,
  week,
  weekEvents,
  currentEvent,
  colorMap,
  swichUser,
  fomatHour,
  handleMousedown,
  columnMouseEnter,
  eventClick,
  scroll,
  hidePopver,
  closeDetail,
  onEdit,
  deleteEvent,
  startChange,
  endChange,
  getScrollbarRef,
  getHeaderRef,
  getPopoverRef
} = useDaily()
</script>

<template>
  <div style="height: 100vh; overflow: hidden; color: #8690A9; font-family: Microsoft YaHei">
    <header style="position: relative;" :ref="getHeaderRef">
      <nav class="navibar">
        <div>
          <el-button color="#3763F7" type="primary" size="small" plain>今天</el-button>
          <el-button-group style="margin-left: 10px;">
            <el-button style="border-right: none; padding-left: 6px; padding-right: 6px;" size="small" color="#3763F7"
              type="primary" plain :icon="ArrowLeft" />
            <el-button style="padding: 0; border-left:none; border-right: none; pointer-events: none;" size="small"
              color="#3763F7" type="primary" plain>
              <span style="color:#C6CED9">|</span>
            </el-button>
            <el-button style="border-left: none; padding-left: 6px; padding-right: 6px;" size="small" color="#3763F7"
              type="primary" plain :icon="ArrowRight" />
          </el-button-group>
        </div>
        <div style="font-size: 16px; font-weight: 400; color: #000;">2023年3月</div>
        <div>
          <span style="vertical-align: -1px">用户：</span>
          <el-select v-model="user" size="small" placeholder="请选择用户" @change="swichUser">
            <el-option label="周乘风" value="1"></el-option>
          </el-select>
        </div>
      </nav>
      <div class="dates">
        <!-- <div class="tz" style="width: 60px; font-size: 12px;">GMT+8</div> -->
        <div class="tz" style="width: 60px; font-size: 12px;"></div>
        <div :class="['date', weekday.today ? 'today' : '']" v-for="(weekday, i) in week">
          <div style="font-size: 12px;">{{ weekday.zhCN }}</div>
          <div style="line-height: 32px;">{{ weekday.enUS }}</div>

          <div v-if="popoverVisible && currentCol === i" style="z-index: 4; bottom: -1px"
            :class="currentEvent ? 'events' : 'placeholder-container'">
            <div class="event-popover-container" :style="popoverVStyle">
              <div class="event-popover" :style="popoverStyle" :type="params.workType" :ref="getPopoverRef">
                <Form :model="params" :work-types="workTypes" @on-start-change="startChange" @on-end-change="endChange" />
                <div style="text-align: right;">
                  <el-button type="primary" size="small">确定</el-button>
                  <el-button size="small" @click="hidePopver">取消</el-button>
                </div>
              </div>
            </div>
          </div>

          <div v-if="detailVisible && currentCol === i" class="events" style="z-index: 4; bottom: -1px">
            <div class="event-popover-container"
              :style="[popoverVStyle, currentEvent ? { '--event-type-color': colorMap.get(currentEvent.type) } : '']">
              <div class="detail" :style="popoverStyle" :ref="getPopoverRef">
                <div class="detail-header">
                  <div class="detail-nav">
                    <span>开发</span>
                    <span class="detail-nav__btns">
                      <el-icon :size="16" @click="onEdit">
                        <EditPen />
                      </el-icon>
                      <el-icon :size="16" @click="deleteEvent">
                        <Delete />
                      </el-icon>
                      <el-icon :size="16" @click="closeDetail">
                        <Close />
                      </el-icon>
                    </span>
                  </div>
                  <div class="detail-title">质量管理V2.0功能质量管理V2.0功能质量管理V2.0功能</div>
                  <div class="detail-subtitle">3月8日（周三）</div>
                </div>
                <div class="detail-footer">
                  <div class="detail-footer__title">详情</div>
                  <p class="detail-footer__content">1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX1、XXXXXXXXX 2、XXXXXXXXX
                    3、XXXXXXXXX1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <div :role="ROLES.MASK" :class="ROLES.MASK" v-if="popoverVisible || detailVisible"></div>
    </header>
    <el-scrollbar :ref="getScrollbarRef" style="height: calc(100% - 95px)"
      :wrap-style="popoverVisible && !shouldDragAndMove ? 'overflow: hidden' : 'overflow: hidden auto'"
      view-style="display: flex; margin-top:0px" @scroll="scroll">
      <aside class="time-line">
        <template v-for="hour in hours">
          <div class="hour" v-if="hour !== 24">{{ fomatHour(hour) + ':00' }}</div>
        </template>
        <div :role="ROLES.MASK" :class="ROLES.MASK" style="right: -1px" v-if="popoverVisible || detailVisible"></div>
      </aside>
      <article class="grids-container" @mousedown="handleMousedown">
        <!-- 7 * (24 * 4) -->
        <div v-for="x in daysInWeek" class="column" :index="x - 1" @mouseenter="columnMouseEnter">
          <template v-for="hour in hours">
            <div v-for="i in 4" :class="ROLES.GRID" :role="ROLES.GRID" :x="x - 1" :y="(hour - 1) * 4 + (i - 1)"></div>
          </template>
          <!-- 日报 -->
          <div class="events" style="z-index: 1; top: 0">
            <div v-for="(e, i) in (weekEvents[x - 1])" :col="x - 1" :row="i"
              :class="[ROLES.EVENT, currentEvent && currentEvent.id === e.id ? 'focus' : '']" :role="ROLES.EVENT"
              :style="[e.style, { '--event-type-color': colorMap.get(e.type) }]"
              @click="eventClick($event, { col: x - 1, data: e })">
              <div class="event-type">
                <span style="margin-right: 3px">设计</span>
                <span>03:00-04:00</span>
              </div>
              <div class="event-title">质量管理V2.0功能质量管理V2.0功能</div>
              <div class="event-detail">1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX</div>
              <div :class="ROLES.RESIZER" :role="ROLES.RESIZER"></div>
            </div>
          </div>
          <!-- 占位符 -->
          <div v-if="placeholderVisible && currentCol === x - 1"
            :class="detailVisible ? 'events' : 'placeholder-container'" style="z-index: 3; top: 0">
            <div :role="ROLES.PLACEHOLDER" :class="currentEvent ? ROLES.EVENT : 'placeholder'"
              :style="[placeholderStyle, detailVisible ? popoverVStyle : '', currentEvent ? { '--event-type-color': colorMap.get(currentEvent.type) } : '']">
              <template v-if="currentEvent">
                <div class="event-type">
                  <span style="margin-right: 3px">设计</span>
                  <span>{{ timeRange }}</span>
                </div>
                <div class="event-title">质量管理V2.0功能质量管理V2.0功能</div>
                <div class="event-detail">1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX</div>
                <div :class="ROLES.RESIZER" :role="ROLES.RESIZER"></div>
              </template>
              <template v-else>
                <div style="padding: 0 2px;">
                  <span style="font-weight: bold; margin-right: 7px;">添加日报</span>
                  <span>{{ timeRange }}</span>
                </div>
              </template>
              <div :class="ROLES.RESIZER" :role="ROLES.RESIZER"></div>
            </div>
          </div>

          <!-- 创建弹窗 -->
          <!-- <div v-if="popoverVisible && currentCol === x - 1" style="z-index: 4; top: 0"
            :class="currentEvent ? 'events' : 'placeholder-container'">
            <div class="event-popover-container" :style="popoverVStyle">
              <div class="event-popover" :style="popoverStyle" :ref="getPopoverRef">
                <Form :model="params" :work-types="workTypes" @on-start-change="startChange" @on-end-change="endChange" />
                <div style="text-align: right;">
                  <el-button type="primary" size="small">确定</el-button>
                  <el-button size="small" @click="hidePopver">取消</el-button>
                </div>
              </div>
            </div>
          </div> -->

          <!-- 详情弹窗 -->
          <!-- <div v-if="detailVisible && currentCol === x - 1" class="events" style="z-index: 4; top: 0">
            <div class="event-popover-container"
              :style="[popoverVStyle, currentEvent ? { '--event-type-color': colorMap.get(currentEvent.type) } : '']">
              <div class="detail" :style="popoverStyle" :ref="getPopoverRef">
                <div class="detail-header">
                  <div class="detail-nav">
                    <span>开发</span>
                    <span class="detail-nav__btns">
                      <el-icon :size="16" @click="onEdit">
                        <EditPen />
                      </el-icon>
                      <el-icon :size="16" @click="deleteEvent">
                        <Delete />
                      </el-icon>
                      <el-icon :size="16" @click="closeDetail">
                        <Close />
                      </el-icon>
                    </span>
                  </div>
                  <div class="detail-title">质量管理V2.0功能质量管理V2.0功能质量管理V2.0功能</div>
                  <div class="detail-subtitle">3月8日（周三）</div>
                </div>
                <div class="detail-footer">
                  <div class="detail-footer__title">详情</div>
                  <p class="detail-footer__content">1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX1、XXXXXXXXX 2、XXXXXXXXX
                    3、XXXXXXXXX1、XXXXXXXXX 2、XXXXXXXXX 3、XXXXXXXXX</p>
                </div>
              </div>
            </div>
          </div> -->

          <!-- 遮罩层 -->
          <div :role="ROLES.MASK" :class="ROLES.MASK" v-if="popoverVisible || detailVisible"></div>
        </div>
      </article>
    </el-scrollbar>
  </div>

  <el-dialog v-model="editDialogVisible" title="" width="50%" align-center>
    <Form :model="params" :work-types="workTypes" />
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="editDialogVisible = false">确定</el-button>
        <el-button @click="editDialogVisible = false">取消</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<style scoped>
.navibar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 42px;
  padding: 0 10px;
  font-size: 12px;
}

.events {
  position: absolute;
}

.dates {
  display: flex;
  border-bottom: 1px solid #DDE2E8;
  user-select: none;
  box-shadow: 0 5px 6px 3px rgba(0, 0, 0, 0.1);
  background-color: #f7f8fa;
}

.dates>div {
  height: 52px;
  padding-left: 10px;
  line-height: 20px;
  border-right: 1px solid #DDE2E8;
}

.dates div:last-child {
  border-color: transparent;
}

.dates .date {
  font-size: 24px;
}

.date {
  flex: 1;
  position: relative;
}

.date.today {
  color: #2071EB;
}

.time-line {
  position: relative;
  width: 60px;
  padding-right: 10px;
  border-right: 1px solid #DDE2E8;
  user-select: none;
}

.hour {
  height: 72px;
  font-size: 12px;
  text-align: right;
  line-height: 72px;
  transform: translateY(50%);
}

.grids-container {
  --event-type-color: 134, 144, 169;
  flex: 1;
  display: flex;
  user-select: none;
}

.column {
  flex: 1;
  position: relative;
}

.grid {
  height: 18px;
  border-right: 1px solid #DDE2E8;
}

.column:last-child .grid {
  border-right-color: transparent;
}

.column .grid:nth-child(4n) {
  border-bottom: 1px solid #DDE2E8;
}

.column .grid:nth-child(96) {
  border-bottom-color: transparent;
}

.events,
.placeholder-container,
.event-popover-container {
  position: absolute;
  height: 0;
  overflow: visible;
}

.events {
  left: 1px;
  right: 5%;
  /* z-index: 1; */
}

.placeholder-container {
  left: 0;
  right: 0;
  z-index: 3;
}

.event-popover-container {
  left: 0;
  right: 0;
}

div[role=placeholder] {
  box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3);
}

.event {
  position: absolute;
  overflow: hidden;
  border-radius: 4px;
  background-color: #fff;
  background-image: linear-gradient(to bottom, rgba(var(--event-type-color), 0.2), rgba(var(--event-type-color), 0.2));
  cursor: pointer;
  font-size: 12px;
}

.event.focus {
  z-index: 9999 !important;
  box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3) !important;
}

.placeholder {
  position: absolute;
  left: 0;
  right: 0;
  overflow: hidden;
  border-radius: 4px;
  border: 1px solid #2058FF;
  background-color: #DEE6FF;
  cursor: pointer;
  color: #2058FF;
  font-size: 12px;
}

.event-type {
  padding: 0 4px;
  height: 19px;
  white-space: nowrap;
  color: #fff;
  background-color: rgb(var(--event-type-color));
  line-height: 19px;
}

.event-title {
  margin: 3px 0;
  padding-left: 10px;
  font-size: 14px;
  color: rgb(var(--event-type-color));
  line-height: 16px;
  max-height: 32px;
  word-break: break-all;
  overflow: hidden;
}

.event-detail {
  padding-left: 10px;
  color: #6C738D;
  word-break: break-all;
}

.event * {
  pointer-events: none;
}

.placeholder * {
  pointer-events: none;
}

.event .event-resizer,
.placeholder .event-resizer {
  pointer-events: inherit;
}

.event-resizer {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 8px;
  cursor: s-resize;
}

.event-popover {
  position: absolute;
  margin: 0 5px;
  padding: 18px 15px;
  width: 500px;
  min-height: 350px;
  border-radius: 4px;
  border: 1px solid #ccc;
  background-color: #fff;
  box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3);
  overflow: hidden;
}

.detail {
  position: absolute;
  margin: 0 5px;
  width: 360px;
  height: 321px;
  border-radius: 4px;
  background-color: #fff;
  box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3);
  line-height: 1;
  font-size: 12px;
  overflow: hidden;
}

.detail-header {
  padding: 0 10px 15px;
  background-color: rgb(var(--event-type-color));
  color: #fff;
  font-size: 12px;
}

.detail-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
}

.detail-title {
  padding: 10px;
  /* background-color: rgb(var(--event-type-color)); */
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  line-height: 20px;
}

.detail-subtitle {
  padding: 0 10px;
}

.detail-footer {
  padding: 10px 20px;
}

.detail-footer__title {
  padding-left: 4px;
  border-left: 2px solid rgb(var(--event-type-color));
}

.detail-footer__content {
  margin-top: 10px;
  color: #000;
  line-height: 14px;
}

.mask {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  background-color: #000;
  opacity: 0.5;
  z-index: 2;
}
</style>
