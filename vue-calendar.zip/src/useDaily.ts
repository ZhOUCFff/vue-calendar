import {
  ref,
  shallowRef,
  reactive,
  shallowReactive,
  onMounted,
  onBeforeUnmount,
  computed,
  nextTick
} from 'vue'
import { isArray } from '@vue/shared'
import {
  startOfWeek,
  addDays,
  setMinutes,
  format,
  isToday,
  hoursToMinutes,
  minutesToHours,
  // getYear,
  // getMonth,
  getHours,
  getMinutes,
  daysInWeek,
  setHours
} from 'date-fns'

import { debounce } from 'radash'

import {
  getServerTime,
  getWeekDaily,
  getWorkTypes,
  getUserList
} from '@/api/daily'

import { hours, totalY, oneStepPx, oneHourSteps, computeSpan, minutesToTime, getWeek, fomatHour } from './util'

import { buildStyle } from './seg-web'
import type { ElScrollbar } from 'element-plus'
import type { EventItem } from './seg-web'
import type { SegEntry } from './seg-hierarchy'

export enum ROLES {
  EVENT = 'event',
  GRID = 'grid',
  RESIZER = 'event-resizer',
  PLACEHOLDER = 'placeholder',
  MASK = 'mask'
}

export const useDaily = () => {
  const loginUser = '' // 当前登录用户
  const user = shallowRef('') // 选择的用户
  // 用户列表
  const userList = shallowRef<{ name: string; id: string }[]>([])
  // 切换用户
  const swichUser = (userId: string) => {
    // 获取切换用户的日报
    // 清除状态
    detailVisible.value = false
    placeholderVisible.value = false
    popoverVisible.value = false
    currentEvent.value = undefined
  }
  const weekEvents = shallowReactive<any[]>([]) // 周日报数据
  const workTypes = shallowRef<Array<{ name: string; id: string }>>([]) // 工作类型列表
  // 颜色rgb值列表
  const colors = [
    '32,88,255',
    '235,161,12',
    '252,85,51',
    '18,148,255',
    '210,77,211',
    '77,69,232',
    '19,196,165',
    '134,201,74',
    '134,144,169'
  ]
  const colorMap = shallowReactive(new Map()) // 色值map
  let scrollbarRef: InstanceType<typeof ElScrollbar> // 滚动条实例
  const week = getWeek(new Date(), 0, 1) // 当前周日期
  const oneStepMinutes = 60 / oneHourSteps // 一个步长表示的分钟数
  const loading = shallowRef(false) // 接口是否调用完毕
  const editDialogVisible = ref(false) // 编辑弹窗是否显示
  const detailVisible = shallowRef(false)// 是否显示详情
  let startY: number // 鼠标事件起始y坐标
  let shouldDragAndMove = shallowRef(false) // 是否允许拖动
  let role: string | null // 鼠标按下的元素角色 事件 | 单元格

  const dragStartY = shallowRef(0) // 拖拽开始时的起始y坐标
  // const _dragStartY = computed(() => {
  //   const { H, m } = minutesToTime(dragStartMinutes.value, false)
  //   return H * oneHourSteps * oneStepPx + Math.round(m / 60 * (oneStepPx * oneHourSteps))
  // })
  const dragEndY = shallowRef(0) // 拖拽开始时的结束y坐标
  const dragStartMinutes = shallowRef() // 拖拽开始位置的分钟数 一个单元格表示 15 分钟
  const dragEndMinutes = shallowRef() // 拖拽结束位置的分钟数
  const currentEvent = shallowRef<EventItem | undefined>(undefined) // 当前鼠标按下的事件
  let dragStartYcache: number // 缓存鼠标按下时当前元素的起始位置
  let dragEndYcache: number
  let dragStartMinutesCache: number
  let dragEndMinutesCache: number
  let dragStartCol: number
  let scrollTop = 0 // 滚动卷去的高度
  let scrollHeight: number = 0 // 滚动可视区域的高度
  let boundaryRange: number = 12 // 距离边界多少触发滚动

  const pageHeight = shallowRef(0) // 当前页面的高度
  const pageWidth = shallowRef(0) // 当前页面的宽度
  const headerHeight = shallowRef(0) // 头部的高度
  const popoverHeight = shallowRef(0) // 弹窗的高度
  let popoverWidth = 0 // 弹窗的宽度
  const timelineWidth = 60 // 左侧时间线的宽度


  const placeholderVisible = shallowRef(false) // 是否显示占位符
  const popoverVisible = shallowRef(false) // 是否显示编辑弹窗
  // 弹窗横向的位置
  const popoverVStyle = shallowReactive<{ left: string | undefined, right: string | undefined }>({
    left: '0',
    right: '0'
  })
  const currentCol = shallowRef(-1) // 点击的周几

  // 表单的参数
  const params = reactive<Record<string, any>>({
    workType: '',
    startTime: '',
    endTime: '',
    detail: ''
  })

  // 1. 请求服务器时间进行同步
  // 2. 请求当前时间周日报数据
  // 3. 请求所有选项
  // 4. 请求所有用户
  // 5. 请求所有工作类型

  async function requestUsers() {
    try {
      userList.value = await getUserList()
    } catch (error) {
      console.log(error + '')
    }
  }

  async function requestWeekDaily() {
    try {
      const serverTime = await getServerTime()
      const data: any[] = await getWeekDaily({
        user: user.value,
        time: serverTime
      })
      for (let i = 0; i < daysInWeek; i++) {
        const dayData = data[i] || []
        if (!isArray(dayData) || dayData.length <= 0) continue
        weekEvents[i] = buildStyle(
          dayData
            .sort((a, b) => a.start - b.start)
            .map((item, i) => {
              item.index = i
              item.thickness = 1
              item.span = computeSpan({ start: item.start, end: item.end })
              return item as SegEntry
            })
        )
      }
    } catch (error) {
      console.log(error + '')
    }
  }

  async function requestWorkTypes() {
    try {
      const types = await getWorkTypes()
      // 构建颜色map
      for (let i = 0, l = types.length, m = colors.length; i < l; i++) {
        const key = types[i]?.id
        colorMap.set(key, colors[i % m])
      }
      workTypes.value = types
    } catch (error) {
      console.log(error + '')
    }
  }

  requestWeekDaily()
  requestUsers()
  requestWorkTypes()

  const getHeaderRef = (e: any) => {
    nextTick(() => {
      headerHeight.value = e?.offsetHeight || 0
    })
    return e
  }

  const getPopoverRef = (e: any) => {
    nextTick(() => {
      popoverHeight.value = e?.offsetHeight || 0
      popoverWidth = e?.offsetWidth || 0
    })
    return e
  }


  // 占位符的绝对定位样式
  const placeholderStyle = computed(() => ({
    top: dragStartY.value + 'px',
    bottom: -dragEndY.value + 'px' // 高度需限制 如 鼠标 超出网格范围
  }))
  // 弹窗的位置计算
  const popoverStyle = computed(() => {
    const startVal = dragStartY.value
    const endVal = dragEndY.value
    const popoverHeightVal = popoverHeight.value

    const topLimit = -headerHeight.value
    const bottomLimit = scrollHeight

    const middle = scrollTop + scrollHeight / 2
    const pageHeightVal = pageHeight.value
    const pageWidthVal = pageWidth.value
    const columnWidth = (pageWidthVal - timelineWidth) / daysInWeek

    const startToMiddle = Math.abs(startVal - middle)
    const endToMiddle = Math.abs(endVal - middle)

    const transform: string[] = []

    const hStyle: {
      top?: string
      bottom?: string
      // transform?: string
    } = {}
    // 谁距离中间值距离小用谁
    if (startToMiddle <= endToMiddle) {
      let top = startVal - scrollTop
      let offset: number
      // 判断是否溢出
      if (top < topLimit) {
        top = topLimit
      }
      // 再判断底部是否溢出
      const bottomOverH = top + popoverHeightVal - scrollHeight
      if (bottomOverH > 0) {
        const free = top - topLimit
        offset = free >= bottomOverH ? bottomOverH : (bottomOverH + free) / 2
        // hStyle.transform = `translateY(-${offset}px)`
        transform.push(`translateY(-${offset}px)`)
      }
      hStyle.top = top + 'px'
    } else {
      let bottom = endVal - scrollTop
      let offset: number

      if (bottom > bottomLimit) {
        bottom = bottomLimit
      }

      // 判断顶部是否溢出
      const topOverH = popoverHeightVal + (scrollHeight - bottom) - pageHeightVal
      if (topOverH > 0) {
        const free = scrollHeight - bottom
        offset = free >= topOverH ? topOverH : (topOverH + free) / 2
        // hStyle.transform = `translateY(${offset}px)`
        transform.push(`translateY(${offset}px)`)
      }
      hStyle.bottom = -bottom + 'px'
    }

    // 判断左右是否溢出
    const vStyle: { left?: string, right?: string, transform?: string } = {}
    if (currentCol.value > 3) {
      const vOver = Math.round((daysInWeek - currentCol.value) * columnWidth + popoverWidth + 5 - pageWidthVal - 14)
      if (vOver > 0) {
        // vStyle.transform = `translateX(${vOver}px)`
        transform.push(`translateX(${vOver}px)`)
      }
      vStyle.right = '100%'
    } else {
      const vOver = Math.round(timelineWidth + (currentCol.value + 1) * columnWidth + popoverWidth + 5 - pageWidthVal - 14)
      if (vOver > 0) {
        // vStyle.transform = `translateX(-${vOver}px)`
        transform.push(`translateX(-${vOver}px)`)
      }
      vStyle.left = '100%'
    }

    if (transform.length > 0) {
      vStyle.transform = transform.join(' ')
    }

    return {
      ...hStyle,
      ...vStyle
    }
  })
  // 计算当前的时间范围
  const timeRange = computed(() => {
    const start = minutesToTime(dragStartMinutes.value, true)
    const end = minutesToTime(dragEndMinutes.value, true)
    // 同时将值绑定到表单中
    params.start = start
    params.end = end
    return start + '-' + end
  })

  /** common */
  // 鼠标按下事件或者resizer
  const eventOrResizerMousedown = (e: MouseEvent, target: HTMLElement) => {
    // 事件准备拖拽
    // 获取事件数据
    const { col, data } = getCurrentEventData(target)

    if (data) {
      // 保存当前时间数据
      currentEvent.value = data
      // 点击的第几列，表示星期几
      currentCol.value = col

      const { start: startTime, end: endTime } = data as EventItem
      const { start, end } = computeSpan({ start: startTime, end: endTime })
      // 设置起始结束位置和起始结束时间
      dragStartY.value = start
      dragEndY.value = end
      dragStartMinutes.value =
        hoursToMinutes(getHours(startTime)) + getMinutes(startTime)
      dragEndMinutes.value =
        hoursToMinutes(getHours(endTime)) + getMinutes(endTime)
    }

    // 缓存初始数据
    dragStartYcache = dragStartY.value // 缓存起始位置
    dragEndYcache = dragEndY.value // 缓存结束位置
    dragStartMinutesCache = dragStartMinutes.value // 缓存起始的分钟数，一格15px表示15分钟
    dragEndMinutesCache = dragEndMinutes.value // 缓存结束的分钟数
    dragStartCol = currentCol.value // 缓存点击的第几列

    startY = e.pageY // 记录鼠标点击的位置
    shouldDragAndMove.value = true // 可以拖动
    // placeholderVisible.value = true
  }

  // 处理公共的mousemove
  const handleMove = (distance: number) => {

    if (currentEvent.value) {
      const _distance = Math.abs(distance)
      // 移动一定距离时才显示
      if (_distance >= 2) {
        placeholderVisible.value = true
      }
      if (_distance < 5) return
    }

    // 拖动的距离是15的倍数
    const dragSetps = Math.ceil(distance / oneStepPx)
    const touchingStartY = dragStartYcache + dragSetps * oneStepPx
    const touchingEndY = dragEndYcache + dragSetps * oneStepPx

    console.log(dragSetps)

    // 拖动到达顶部
    if (touchingStartY < 0 && distance < 0) {
      return
    }

    // 拖动到达底部
    if (touchingEndY > totalY && distance > 0) {
      return
    }

    const movedY = dragSetps * oneStepPx
    const movedTime = dragSetps * oneStepMinutes
    dragStartY.value = dragStartYcache + movedY
    dragEndY.value = dragEndYcache + movedY
    dragStartMinutes.value = dragStartMinutesCache + movedTime
    dragEndMinutes.value = dragEndMinutesCache + movedTime
  }

  let currentY: number
  const updateScrolltop = (newScrollTop: number) => {
    if (!scrollbarRef) return
    const offsetY = newScrollTop - scrollTop
    scrollbarRef.wrapRef!.scrollTop = newScrollTop
    scrollTop = newScrollTop
    startY = startY - offsetY
  }
  const bottomBoundaryHandler = (y: number, isDrag: boolean) => {
    // 到达底部并且向下
    if (y > currentY) {
      // 到达临界值
      if (dragEndY.value + oneStepPx > totalY) {
        // scrollbarRef!.setScrollTop(totalY)
        updateScrolltop(totalY - scrollHeight)
        return
      }

      if (isDrag) {
        dragStartY.value = dragStartY.value + oneStepPx
        dragEndY.value = dragEndY.value + oneStepPx
        dragStartMinutes.value = dragStartMinutes.value + oneStepMinutes
        dragEndMinutes.value = dragEndMinutes.value + oneStepMinutes
        updateScrolltop(scrollTop + oneStepPx)
      } else {
        if (dragEndY.value > scrollTop + scrollHeight) {
          if (dragStartY.value + oneStepPx >= dragEndY.value) {
            updateScrolltop(dragEndY.value - scrollHeight)
          }
          dragStartY.value = dragStartY.value + oneStepPx
          dragStartMinutes.value = dragStartMinutes.value + oneStepMinutes
          updateScrolltop(scrollTop + oneStepPx)
        } else {
          dragEndY.value = dragEndY.value + oneStepPx
          dragEndMinutes.value = dragEndMinutes.value + oneStepMinutes
          updateScrolltop(dragEndY.value - scrollHeight)
        }
      }
    }
    currentY = y
  }

  const topBoundaryHandler = (y: number, isDrag: boolean, isResizer = false) => {
    if (y < currentY) {
      if (dragStartY.value - oneStepPx < 0) {
        updateScrolltop(0)
        return
      }

      if (isDrag) {
        dragStartY.value = dragStartY.value - oneStepPx
        dragEndY.value = dragEndY.value - oneStepPx
        dragStartMinutes.value = dragStartMinutes.value - oneStepMinutes
        dragEndMinutes.value = dragEndMinutes.value - oneStepMinutes
        updateScrolltop(scrollTop - oneStepPx)
      } else {

        if (isResizer) {
          if (dragStartY.value <= scrollTop) {
            if (dragEndY.value - dragStartY.value <= oneStepPx) {
              updateScrolltop(dragStartY.value)
              return
            }
            dragEndY.value = dragEndY.value - oneStepPx
            dragEndMinutes.value = dragEndMinutes.value - oneStepMinutes
            updateScrolltop(scrollTop - (dragStartY.value === scrollTop ? 0 : oneStepPx))
          }
        } else {
          if (dragStartY.value < scrollTop) {
            if (dragEndY.value - dragStartY.value <= oneStepPx) {
              updateScrolltop(dragStartY.value)
              return
            }
            dragEndY.value = dragEndY.value - oneStepPx
            dragEndMinutes.value = dragEndMinutes.value - oneStepMinutes
            updateScrolltop(scrollTop - oneStepPx)
          } else {
            dragStartY.value = dragStartY.value - oneStepPx
            dragStartMinutes.value = dragStartMinutes.value - oneStepMinutes
            updateScrolltop(dragStartY.value)
          }
        }
      }
    }
    currentY = y
  }

  const getCurrentEventData = (
    target: HTMLElement
  ): { col: number; row: number; data: EventItem | undefined } => {
    let col: string | number | null = target.getAttribute('col')
    col = col === null ? -1 : +col
    let row: string | number | null = target.getAttribute('row')
    row = row === null ? -1 : +row
    return {
      col,
      row,
      data: col >= 0 && row >= 0 ? weekEvents[col][row] : undefined
    }
  }

  /** event */
  const columnMouseEnter = (e: MouseEvent) => {
    if (!shouldDragAndMove.value) return
    if (role !== ROLES.EVENT && role !== ROLES.PLACEHOLDER) return
    const target = e.target as HTMLElement
    const index = +(target.getAttribute('index') as string)
    currentCol.value = index
  }

  const scroll = (value: { scrollTop: number }) => {
    scrollTop = value.scrollTop
  }

  const eventClick = (
    e: MouseEvent,
    position: { col: number; data: EventItem }
  ) => {
    e.stopPropagation()
    if (
      loading.value ||
      currentEvent.value ||
      placeholderVisible.value ||
      popoverVisible.value
    )
      return

    const { col, data } = position
    // 点击事件
    // 显示事件详情
    currentCol.value = col
    currentEvent.value = data
    const { start: startTime, end: endTime, style } = data
    const { start, end } = computeSpan({ start: startTime, end: endTime })
    dragStartY.value = start
    dragEndY.value = end
    dragStartMinutes.value =
      hoursToMinutes(getHours(startTime)) + getMinutes(startTime)
    dragEndMinutes.value =
      hoursToMinutes(getHours(endTime)) + getMinutes(endTime)

    popoverVStyle.left = style && style.left
    popoverVStyle.right = style && style.right

    placeholderVisible.value = true

    detailVisible.value = true
  }

  let downTime: number
  // 鼠标按下页面元素
  const handleMousedown = (e: MouseEvent) => {
    downTime = new Date().getTime()
    // if (detailVisible.value || loading.value) return
    if (loading.value) return
    let target = e.target as HTMLElement
    role = target.getAttribute('role')

    switch (role) {
      // 如果按下的是单元格，表示创建日报
      case ROLES.GRID: {
        if (placeholderVisible.value || popoverVisible.value) return
        popoverVStyle.left = '0'
        popoverVStyle.right = '0'
        const x = +(target.getAttribute('x') as string)
        const y = +(target.getAttribute('y') as string)
        // startY = target.getBoundingClientRect().y
        startY = e.pageY
        currentCol.value = x
        // startStep.value = y
        dragStartY.value = y * oneStepPx
        dragEndY.value = dragStartY.value + oneStepPx
        dragStartMinutes.value = y * oneStepMinutes
        dragEndMinutes.value = dragStartMinutes.value + oneStepMinutes
        dragStartYcache = dragStartY.value
        dragEndYcache = dragEndY.value
        dragStartMinutesCache = dragStartMinutes.value
        dragEndMinutesCache = dragEndMinutes.value
        placeholderVisible.value = true
        dragStartCol = currentCol.value
        shouldDragAndMove.value = true
        break
      }
      // 如果点击的是已经存在的事件
      case ROLES.EVENT: {
        // 鼠标按下事件
        // 什么情况下不允许
        // 编辑弹窗 或者 占位符 已显示，再按下事件无效
        if (placeholderVisible.value || popoverVisible.value) return
        eventOrResizerMousedown(e, target)
        break
      }
      case ROLES.PLACEHOLDER: {
        // 如果拖动的是占位符
        // 直接允许拖动
        dragStartYcache = dragStartY.value // 缓存起始位置
        dragEndYcache = dragEndY.value // 缓存结束位置
        dragStartMinutesCache = dragStartMinutes.value // 缓存起始的分钟数，一格15px表示15分钟
        dragEndMinutesCache = dragEndMinutes.value // 缓存结束的分钟数
        dragStartCol = currentCol.value // 缓存点击的第几列

        startY = e.pageY // 记录鼠标点击的位置
        shouldDragAndMove.value = true // 可以拖动
        break
      }
      // 点击的是拖动改变大小
      case ROLES.RESIZER: {
        target = target.parentElement as HTMLElement
        const parentRole = target.getAttribute('role')
        // 如果是placeholder存在那么只允许拖placeholder的resizer
        if (placeholderVisible.value && parentRole !== ROLES.PLACEHOLDER) return
        // 什么情况下无法拖动调整大小
        // 如果是正在编辑日报则无法调整大小
        // if (currentEvent.value && popoverVisible.value) return
        eventOrResizerMousedown(e, target)
        break
      }
    }
  }

  // 拖动
  const documentMouseMove = (e: MouseEvent) => {
    if (loading.value) return
    if (!shouldDragAndMove.value) return

    if (Date.now() - downTime <= 100) {
      return
    }

    const y = e.pageY
    const distance = y - startY
    // 上边界条件
    const topBoundaryCondition = y <= headerHeight.value + boundaryRange && scrollTop > 0
    // 下边界条件
    const bottomBoundaryCondition = pageHeight.value - y <= boundaryRange && scrollTop + scrollHeight < totalY

    switch (role) {
      case ROLES.GRID: {
        // 如果此时详情弹窗显示则不执行
        if (popoverVisible.value) return

        let dragSetps = Math.ceil(distance / oneStepPx)


        if (bottomBoundaryCondition) {
          return bottomBoundaryHandler(y, false)
        }

        if (topBoundaryCondition) {
          return topBoundaryHandler(y, false)
        }

        if (dragSetps > 0) {
          dragStartY.value = dragStartYcache
          dragStartMinutes.value = dragStartMinutesCache
          dragEndY.value = dragEndYcache + dragSetps * oneStepPx
          dragEndMinutes.value =
            dragEndMinutesCache + dragSetps * oneStepMinutes
        } else {
          dragEndY.value = dragEndYcache
          dragEndMinutes.value = dragEndMinutesCache
          dragStartY.value = dragStartYcache + dragSetps * oneStepPx
          dragStartMinutes.value =
            dragStartMinutesCache + dragSetps * oneStepMinutes
        }

        if (dragStartY.value < 0) {
          dragStartY.value = 0
          dragStartMinutes.value = 0
        }

        if (dragEndY.value > totalY) {
          dragEndY.value = totalY
          dragEndMinutes.value = 24 * 60
        }
        break
      }
      case ROLES.EVENT: {
        if (bottomBoundaryCondition) {
          return bottomBoundaryHandler(y, true)
        }
        if (topBoundaryCondition) {
          return topBoundaryHandler(y, true)
        }
        handleMove(distance)
        break
      }
      case ROLES.PLACEHOLDER: {
        if (popoverVisible.value) {
          popoverVisible.value = false
        }

        if (detailVisible.value) {
          detailVisible.value = false
        }

        if (bottomBoundaryCondition) {
          return bottomBoundaryHandler(y, true)
        }

        if (topBoundaryCondition) {
          return topBoundaryHandler(y, true)
        }

        handleMove(distance)
        break
      }
      case ROLES.RESIZER: {
        if (currentEvent.value) {
          placeholderVisible.value = true
          if (Math.abs(distance) < 5) return
        }

        if (detailVisible.value) {
          detailVisible.value = false
        }

        if (bottomBoundaryCondition) {
          return bottomBoundaryHandler(y, false)
        }

        // 鼠标到达屏幕顶部
        if (topBoundaryCondition) {
          return topBoundaryHandler(y, false, true)
        }

        // 拖动的是15的倍数
        const dragSetps = Math.ceil(distance / oneStepPx)
        const touchingEndY = dragEndYcache + dragSetps * oneStepPx

        if (touchingEndY - dragStartYcache < oneStepPx) {
          return
        }

        if (touchingEndY > totalY && distance > 0) {
          return
        }

        const movedY = dragSetps * oneStepPx
        const movedTime = dragSetps * oneStepMinutes
        dragStartY.value = dragStartYcache
        dragEndY.value = dragEndYcache + movedY
        dragStartMinutes.value = dragStartMinutesCache
        dragEndMinutes.value = dragEndMinutesCache + movedTime
        break
      }
    }
  }

  // 松开鼠标
  const documentMouseup = (e: MouseEvent) => {
    // 如果接口还未响应
    if (!shouldDragAndMove.value || loading.value) return
    shouldDragAndMove.value = false
    switch (role) {
      case ROLES.GRID: {
        // 说明是新创建事件
        // 显示编辑创建弹窗
        popoverVisible.value = true
      }
      // 如果松开鼠标时是事件，说明刚开始点击的就是事件
      // 鼠标按下时事件，无非就是拖动或者点击
      case ROLES.EVENT: {
        console.log(role)
        if (currentEvent.value) {
          saveEvent(currentEvent.value)
          // 隐藏占位符
          placeholderVisible.value = false
          currentEvent.value = undefined
        }
        break
      }
      case ROLES.PLACEHOLDER: {
        // debugger
        // 如果鼠标松开是占位符
        // 鼠标按下时也是占位符，拖动占位符
        if (currentEvent.value) {
          // 如果当前事件存在则需要保存事件
          // 如果编辑创建弹窗显示
          if (popoverVisible.value) {
            // 需点击编辑弹窗保存进行保存
            // do noting
          } else {
            // 编辑弹窗未显示直接保存
            saveEvent(currentEvent.value)
          }
        } else {
          // 当前事件不存在则是创建
          if (!popoverVisible.value) {
            popoverVisible.value = true
          }
        }
        break
      }
      case ROLES.RESIZER: {
        // 如果鼠标按下的是 resizer 调整大小
        // 1. 在占位符点击的resizer
        // 2. 在已经存在的事件上点击resizer
        if (currentEvent.value) {
          // 保存调整后的事件
          saveEvent(currentEvent.value)
        }
        break
      }
    }
  }

  const documentClick = (e: MouseEvent) => {
    if (!detailVisible.value) return
    const target = e.target as HTMLElement
    const role = target.getAttribute('role')
    if (role === ROLES.MASK) {
      closeDetail()
    }
  }

  // 窗口大小变化
  const resize = debounce({ delay: 300 }, () => {
    pageHeight.value = document.body.clientHeight
    pageWidth.value = document.body.clientWidth
    scrollHeight = scrollbarRef.wrapRef?.clientHeight || 0
    boundaryRange = scrollHeight < 24 ? scrollHeight / 2 : 12
  })

  /** methods */
  const getScrollbarRef = (e: InstanceType<typeof ElScrollbar>) =>
    (scrollbarRef = e)

  // 表单选择开始时间
  const startChange = (val: string) => {
    // 判断开始位置是否超出滚动区域
    const [H, m] = val.split(':').map(Number)
    const fullStep = oneStepPx * oneHourSteps
    dragStartY.value = H * fullStep + Math.round((m / 60) * fullStep)
    dragStartMinutes.value = H * 60 + m
    if (dragStartY.value < scrollTop) {
      scrollbarRef.setScrollTop(dragStartY.value)
    }
  }
  // 表单选择结束时间
  const endChange = (val: string) => {
    if (!val) return
    let [H, m] = val.split(':').map(Number)
    const fullStep = oneStepPx * oneHourSteps
    if (H === 0 && m === 0) {
      H = 24
      m = 0
    }
    dragEndY.value = H * fullStep + Math.round((m / 60) * fullStep)
    dragEndMinutes.value = H * 60 + m
    const over = dragEndY.value - (scrollHeight + scrollTop)
    if (over > 0) {
      // 获取超出部分
      let _scrollTop = scrollTop + over
      if (dragStartY.value <= _scrollTop) {
        _scrollTop = dragStartY.value
      }
      scrollbarRef.setScrollTop(_scrollTop)
    }
  }

  const hidePopver = () => {
    // 隐藏弹窗
    popoverVisible.value = false
    placeholderVisible.value = false
    // 清空数据
    currentEvent.value = undefined
  }

  // 点击详情编辑按钮
  const onEdit = () => {
    // 显示编辑弹窗
    // 将表单值进行绑定
    if (currentEvent.value) {
      const { start, end, detail } = currentEvent.value
      params.detail = detail
    }
    editDialogVisible.value = true
  }

  const deleteEvent = () => { }

  // 点击详情关闭按钮
  const closeDetail = () => {
    detailVisible.value = false
    placeholderVisible.value = false
    currentEvent.value = undefined
  }

  function saveEvent(eventData: EventItem) {
    // 如果还是原来的位置则不需要更新

    if (
      dragStartMinutesCache === dragStartMinutes.value &&
      dragEndMinutesCache === dragEndMinutes.value &&
      dragStartCol === currentCol.value
    ) {
      // 如果详情未显示 但是 占位符还显示 那么隐藏占位符
      if (!detailVisible.value && placeholderVisible.value) {
        placeholderVisible.value = false
        currentEvent.value = undefined
      }
      return
    }
    const daysToAdd = currentCol.value - dragStartCol

    let { start, end } = eventData
    const startTime = minutesToTime(dragStartMinutes.value)
    const endTime = minutesToTime(dragEndMinutes.value)
    start = setHours(
      setMinutes(addDays(start, daysToAdd), startTime.m),
      startTime.H
    ).getTime()
    end = setHours(
      setMinutes(addDays(end, daysToAdd), endTime.H),
      endTime.m
    ).getTime()
    currentEvent.value = undefined
    // 如果此时详情显示则需要关闭详情显示
    if (detailVisible.value) {
      detailVisible.value = false
    }

    if (placeholderVisible.value) {
      placeholderVisible.value = false
    }

    // 调用接口保存
    // loading.value = true
  }

  /** lifecycles */
  onMounted(() => {
    pageHeight.value = document.body.clientHeight
    pageWidth.value = document.body.clientWidth
    scrollHeight = scrollbarRef.wrapRef?.clientHeight || 0
    boundaryRange = scrollHeight < 24 ? scrollHeight / 2 : 12
    document.addEventListener('mouseup', documentMouseup)
    document.addEventListener('mousemove', documentMouseMove)
    document.addEventListener('click', documentClick)
    window.addEventListener('resize', resize)
    scrollbarRef.setScrollTop(8 * oneHourSteps * oneStepPx)
  })

  onBeforeUnmount(() => {
    document.removeEventListener('mouseup', documentMouseup)
    document.removeEventListener('mousemove', documentMouseMove)
    document.removeEventListener('click', documentClick)
    window.removeEventListener('resize', resize)
  })

  return {
    params,
    workTypes,
    user,
    placeholderStyle,
    timeRange,
    shouldDragAndMove,
    placeholderVisible,
    popoverVStyle,
    popoverVisible,
    detailVisible,
    editDialogVisible,
    popoverStyle,
    currentCol,
    hours,
    daysInWeek,
    week,
    weekEvents,
    currentEvent,
    colorMap,
    swichUser,
    fomatHour,
    handleMousedown,
    columnMouseEnter,
    eventClick,
    scroll,
    hidePopver,
    onEdit,
    deleteEvent,
    closeDetail,
    startChange,
    endChange,
    getScrollbarRef,
    getHeaderRef,
    getPopoverRef
  }
}
