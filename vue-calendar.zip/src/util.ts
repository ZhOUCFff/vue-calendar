import {
  startOfWeek,
  addDays,
  setMinutes,
  format,
  isToday,
  hoursToMinutes,
  minutesToHours,
  getHours,
  getMinutes,
  daysInWeek,
  setHours
} from 'date-fns'

export const hours = 24
// 一个单元格高度
export const oneStepPx = 18
// 一个小时拥有的单元格数
export const oneHourSteps = 4
// 总高度
export const totalY = hours * oneStepPx * oneHourSteps
// 格式化小时
export const fomatHour = (H: number) => H < 10 ? '0' + H : H === 24 ? '00' : H

// 根据时间计算所处页面的绝对定位top 和 bottom
export function computeSpan(date: { start: Date; end: Date }): {
  start: number
  end: number
}
export function computeSpan(date: { start: number; end: number }): {
  start: number
  end: number
}
export function computeSpan(date: { start: Date | number; end: Date | number }) {
  const { start, end } = date
  const fullStep = oneStepPx * oneHourSteps
  date.start =
    fullStep * getHours(start) + Math.round((getMinutes(start) / 60) * fullStep)
  date.end =
    fullStep * getHours(end) + Math.ceil((getMinutes(end) / 60) * fullStep)
  return date
}

// 将分钟数转换为格式化的 小时分钟 00:00
export function minutesToTime(minutes: number, format: true): string
export function minutesToTime(
  minutes: number,
  format?: false
): { H: number; m: number }
export function minutesToTime(
  minutes: number,
  format = false
): string | { H: number; m: number } {
  let H: string | number = minutesToHours(minutes)
  H = format ? fomatHour(H) : H
  let m: string | number = minutes % 60
  m = (format && m < 10) ? '0' + m : m
  return format ? H + ':' + m : { H: H as number, m: m as number }
}

// 获取周
export const getWeek = (
  date: Date | number,
  offset: number,
  weekStartsOn: 0 | 1 | 2 | 3 | 4 | 5 | 6 | undefined
) => {
  weekStartsOn = weekStartsOn || 0
  const arr = ['日', '一', '二', '三', '四', '五', '六']
  let start = startOfWeek(date, {
    weekStartsOn
  })
  start = addDays(start, offset * daysInWeek)
  const weekdays = []
  for (let i = 0; i < daysInWeek; i++) {
    const date = addDays(start, i)
    const weekday: {
      zhCN: string
      enUS: string
      today?: boolean
    } = {
      zhCN: '周' + arr[(i + (weekStartsOn || 0)) % daysInWeek],
      enUS: format(date, 'dd')
      // date: date
    }
    // 判断是不是今天，如果offset不为0，必然不包括今天
    if (offset === 0 && isToday(date)) {
      // 是今天
      weekday.today = true
    }
    weekdays.push(weekday)
  }
  return weekdays
}